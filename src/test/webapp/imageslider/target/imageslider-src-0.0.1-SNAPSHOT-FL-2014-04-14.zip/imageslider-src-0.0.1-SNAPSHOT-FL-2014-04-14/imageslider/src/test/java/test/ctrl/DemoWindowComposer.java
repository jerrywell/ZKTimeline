package test.ctrl;

import org.zkoss.imageslider.ImageSlider;

import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zul.Button;
import org.zkoss.zul.Image;
import org.zkoss.zul.Spinner;

public class DemoWindowComposer extends SelectorComposer<Component> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Wire
	private ImageSlider imageSlider;
	
	@Wire
	private Spinner imageWidthQuantity;
	
	@Wire
	private Spinner viewportQuantity;
	
	@Wire
	private Spinner selectedIndexQuantity;
	
	
	public void doAfterCompose(Component comp) throws Exception {
		super.doAfterCompose(comp);
//		myComp.setText("Hello ZK Component!! Please click me.");
				
	}
	
	/* Event method */
	
	@Listen("onClick = #setViewport")
	public void testSetViewport(){
		System.out.println("test!!!!! in testSetViewport....");
		imageSlider.setViewportSize(viewportQuantity.getValue());
	}
	
	@Listen("onClick = #setImageWidth")
	public void testSetImageWidth(){
		System.out.println("test!!!!! in testSetImageWidth....");
		imageSlider.setImageWidth(imageWidthQuantity.getValue());
	}
	
	@Listen("onClick = #setSelectedIndex")
	public void testSetSelectedIndex(){
		System.out.println("test!!!!! in testSetSelectedIndex....");
		imageSlider.setSelectedIndex(selectedIndexQuantity.getValue());
	}
	
	@Listen("onClick = #addImage")
	public void testAddImage(){
		System.out.println("test!!!!! in testAddImage....");
		Image image = new Image();
		image.setSrc("resources/img/ironman-01.jpg");
		imageSlider.appendChild(image);
	}
	
	@Listen("onClick = #removeImage")
	public void testRemoveImage(){
		System.out.println("test!!!!! in testRemoveImage....");
		Image image = imageSlider.getSelectedItem();
		imageSlider.removeChild(image);
	}
}