package org.zkoss.imageslider;

public class Version {
	/** Returns the version UID.
	 */
	public static final String UID = "0.0.1-SNAPSHOT";
}
